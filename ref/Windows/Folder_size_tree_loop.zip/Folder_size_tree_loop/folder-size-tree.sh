#!/bin/bash
#// AI-generated code

function  ShowHelp() {
    cat  <<_HERE_DOCUMENT
folder-size-tree.sh - フォルダーごとの合計サイズを、Folder_size_tree.html で読み込める形式で出力します
folder-size-tree.sh - Writes the total size of each folder in the format that Folder_size_tree.html can load.

使い方:
Usage:
    folder-size-tree.sh  [__RootFolderPath__]  [--out-file __OutFilePath__]

    __RootFolderPath__  走査するフォルダー。省略すると、このスクリプトの DefaultRootPath
                        Folder to scan. If omitted, DefaultRootPath in this script is used.
    --out-file, -o      出力先。省略すると、このスクリプトファイル自身があるフォルダーの
                        Folder_size_tree_out.yaml (走査対象のフォルダーではない)
                        Output file. If omitted, Folder_size_tree_out.yaml in the folder that
                        contains this script file (not the folder to scan).
    --help, -h          このヘルプを表示する
                        Show this help.

例:
Example:
    \${HOME}/bin/folder-size-tree.sh  "/home/me/projects"

前提: bash、find、awk、sort があるホスト。Linux と macOS で動きます。zsh や sh ではなく bash で実行してください
Requires: a host with bash, find, awk and sort. Works on Linux and macOS. Run it with bash, not zsh or sh.
    find に -printf がない(GNU 版でない)ホストでは、ファイルのサイズを stat で読むので遅くなります
    On hosts whose find has no -printf (not the GNU version), file sizes are read with stat, which is slower.
_HERE_DOCUMENT
}

#region: GlobalVariables

#// フォルダーを指定しなかったときに走査するフォルダー。自分の環境に合わせて書き換えてください
#// Folder to scan when no folder is specified. Edit this to match your environment.
DefaultRootPath="/home/me/projects"

#// 出力先を指定しなかったときのファイル名
#// File name used when no output file is specified.
DefaultOutFileName="Folder_size_tree_out.yaml"

#endregion:

#region: CommandLineOptions

Options_OutFile=""
Options_Help=""
PositionalArgs=()
while [[ $# -gt 0 ]]; do
    case $1 in
        -o|--out-file)  Options_OutFile="$2"; shift; shift;;  #search: bash default values
        -h|--help)  Options_Help="yes"; shift;;
        -*) echo "Unknown option $1"; exit 1;;
        *) PositionalArgs+=("$1"); shift;;
    esac
done
set -- "${PositionalArgs[@]}"  #// set $1, $2, ...
unset PositionalArgs

#endregion:

#region: Main

function  Main() {
    #// 指定したフォルダーを走査し、フォルダーごとの合計サイズをファイルに書き出す
    #// Scans the specified folder and writes the total size of each folder to a file.
    local  rootPath="${1-""}"
    local  outFile="${Options_OutFile}"
    local  scriptFolderPath=""
    local  startSeconds=0
    local  listingMode=""
    local  treeText=""
    if [ "${Options_Help}" == "yes" ]; then
        ShowHelp
        exit  0
    fi
    if [ "${rootPath}" == "" ]; then
        rootPath="${DefaultRootPath}"
    fi
    if [ ! -d "${rootPath}" ]; then
        Error  "ERROR: フォルダーが見つかりません (folder not found): ${rootPath}"
    fi
    rootPath="$( cd  "${rootPath}"  &&  pwd -P )"  ||  Error  "ERROR: パスを解決できません (cannot resolve path): ${rootPath}"
    listingMode="$( GetFileListingMode  "${rootPath}" )"  ||  Error
    if [ "${outFile}" == "" ]; then
        scriptFolderPath="$( cd  "$( dirname  "${BASH_SOURCE[0]}" )"  &&  pwd )"  ||  Error
        outFile="${scriptFolderPath}/${DefaultOutFileName}"
    fi
    startSeconds="${SECONDS}"

    treeText="$( ListFolderAndFileEntries  "${rootPath}"  "${listingMode}"  |  GetFolderSizeTree  "${rootPath}" )"  ||  Error  "ERROR: 走査に失敗しました (scan failed): ${rootPath}"

    echo  "Elapsed: $( FormatElapsedSeconds  "$(( SECONDS - startSeconds ))" )"  >&2

    echo  "${treeText}"  >  "${outFile}"  ||  Error  "ERROR: 書き込めません (cannot write): ${outFile}"

    echo  "Output written to: ${outFile}"
}

#endregion:

#region: FileSystem

function  GetFileListingMode() {
    #// このホストで、ファイルのサイズを読む方法を返す
    #// Returns how file sizes can be read on this host.
    #//     find-printf: GNU find の -printf (Linux の多く)
    #//     stat-c:      stat -c (GNU coreutils、BusyBox)
    #//     stat-f:      stat -f (macOS、BSD)
    #// どれも使えなければエラーで止める。確かめずに走査すると、find がエラーになってもサイズ 0 の結果が書き出される
    #// Stops with an error if none is available. Scanning without this check writes a result with size 0 when find fails.
    local  folderPath="$1"
    if find  "${folderPath}"  -maxdepth 0  -printf ''  > /dev/null  2>&1; then

        echo  "find-printf"
    elif stat  -c '%s'  "${folderPath}"  > /dev/null  2>&1; then

        echo  "stat-c"
    elif stat  -f '%z'  "${folderPath}"  > /dev/null  2>&1; then

        echo  "stat-f"
    else
        Error  "ERROR: ファイルのサイズを読めません。GNU find の -printf か、stat -c か stat -f が必要です (cannot read file sizes: needs GNU find -printf, stat -c or stat -f)"
    fi
}

function  ListFolderAndFileEntries() {
    #// 引数のフォルダー以下のフォルダーとファイルを、1行に1つずつ返す
    #// Returns the folders and files under the given folder, one per line.
    #//     フォルダーの行: D<タブ>フォルダーのパス
    #//     Folder line:    D<tab>FolderPath
    #//     ファイルの行:   F<タブ>サイズ(バイト)<タブ>親フォルダーのパス
    #//     File line:      F<tab>Size (bytes)<tab>ParentFolderPath
    #// サイズは、ファイルの見かけのサイズ。シンボリックリンクはたどらない。隠しファイル(名前が . で始まるもの)も含める。
    #// 読めないフォルダーの中身は含めない(そのエラーは表示しない)
    #// Size is the apparent file size. Symbolic links are not followed. Hidden files (names starting with .) are included.
    #// Contents of unreadable folders are not included (those errors are not shown).
    local  rootPath="$1"
    local  listingMode="$2"  #// GetFileListingMode の出力 (output of GetFileListingMode)

    {
        if [ "${listingMode}" == "find-printf" ]; then

            find  "${rootPath}"  -type d  -printf 'D\t%p\n'
            find  "${rootPath}"  -type f  -printf 'F\t%s\t%h\n'
        else
            find  "${rootPath}"  -type d  |  awk  '{ print "D\t" $0 }'
            {
                if [ "${listingMode}" == "stat-c" ]; then

                    find  "${rootPath}"  -type f  -exec stat  -c $'%s\t%n'  {}  +
                else

                    find  "${rootPath}"  -type f  -exec stat  -f '%z%t%N'  {}  +
                fi
            }  |
                awk  -F '\t'  '
                    #// 「サイズ<タブ>パス」を「F<タブ>サイズ<タブ>親フォルダーのパス」にする
                    {
                        parentPath = $2
                        sub(/\/[^\/]*$/, "", parentPath)
                        if (parentPath == "") {
                            parentPath = "/"
                        }
                        printf("F\t%s\t%s\n", $1, parentPath)
                    }
                '
        fi
    }  2>  /dev/null
}

function  GetFolderSizeTree() {
    #// stdin の ListFolderAndFileEntries の出力から、フォルダーごとの合計サイズ(バイト)をツリー形式の YAML で返す
    #// From the output of ListFolderAndFileEntries on stdin, returns the total size (bytes) of each folder as a YAML tree.
    #//     出力の行: (深さ×空白4つ)フォルダー名:  #// 3桁区切りのサイズ
    #//     Output line: (depth x 4 spaces)FolderName:  #// size with thousands separators
    #// 引数は、ListFolderAndFileEntries に渡した走査対象のフォルダーのパス
    #// The argument is the path of the folder to scan that was passed to ListFolderAndFileEntries.
    #// 名前にタブや改行を含むフォルダーやファイルは、正しく扱えない
    #// Folders and files whose names contain a tab or a newline are not handled correctly.
    #// 進捗と走査結果の概要は stderr に出す
    #// Progress and the scan summary are written to stderr.
    local  rootPath="$1"

    awk  -F '\t'  -v rootPath="${rootPath}"  '  #// function stdin
        #// 1パス目: 全フォルダーを登録し、ファイルのサイズを親フォルダーへ積み上げる
        $1 == "D" {
            folderSize[$2] = 0
            next
        }
        $1 == "F" {
            fileCount++
            totalBytes += $2
            current = $3
            while (1) {
                if (current in folderSize) {
                    folderSize[current] += $2
                }
                if (current == rootPath  ||  current == "/"  ||  current == "") {
                    break
                }
                sub(/\/[^\/]*$/, "", current)
                #// "/x" の親は "/"(sub の結果は空になる)
                if (current == "") {
                    current = "/"
                }
            }
            if (fileCount % 10000 == 0) {
                printf("\rFiles: %s / Bytes: %s", AddCommas(fileCount), AddCommas(totalBytes))  >  "/dev/stderr"
            }
            next
        }
        END {
            printf("\rScan completed: %s files, %s bytes\n", AddCommas(fileCount), AddCommas(totalBytes))  >  "/dev/stderr"
            #// 並べ替え用のキー: "/" を \001 に置き換えると、親の直後に子が並び、兄弟は名前順になる
            for (path in folderSize) {
                #// 走査対象が "/" のときは、パスそのものがルートからの相対パス(先頭の "/" を残す)
                if (rootPath == "/") {
                    relativePath = (path == "/") ? "" : path
                } else {
                    relativePath = substr(path, length(rootPath) + 1)
                }
                depth = gsub(/\//, "/", relativePath)
                sortKey = relativePath
                gsub(/\//, "\001", sortKey)
                name = path
                sub(/^.*\//, "", name)
                if (name == "") {
                    name = "/"
                }
                printf("%s\t%d\t%s\t%s\n", sortKey, depth, name, AddCommas(folderSize[path]))
            }
        }
        function AddCommas(number,    text, result) {
            text = sprintf("%.0f", number)
            result = ""
            while (length(text) > 3) {
                result = "," substr(text, length(text) - 2) result
                text = substr(text, 1, length(text) - 3)
            }
            return text result
        }
    '  |
    LC_ALL=C  sort  -t $'\t'  -k 1,1  |
    awk  -F '\t'  '
        {
            indent = ""
            for (i = 0;  i < $2;  i++) {
                indent = indent "    "
            }
            printf("%s%s:  #// %s\n", indent, $3, $4)
        }
    '
}

#endregion:

#region: TimeFormat

function  FormatElapsedSeconds() {
    #// 秒数を hh:mm:ss 形式の文字列にする
    #// Formats a number of seconds as hh:mm:ss.
    local  seconds="$1"

    printf  '%02d:%02d:%02d'  "$(( seconds / 3600 ))"  "$(( seconds % 3600 / 60 ))"  "$(( seconds % 60 ))"
}

#endregion:

#region: Error

function  Error() {
    local  errorMessage="${1-""}"  #// "${1-""}" means that "$1" default is "".
    if [ "${errorMessage}" == "" ]; then
        errorMessage="ERROR"
    fi

    echo  "${errorMessage}"  >&2
    exit  1
}

#endregion:

Main  "$@"
