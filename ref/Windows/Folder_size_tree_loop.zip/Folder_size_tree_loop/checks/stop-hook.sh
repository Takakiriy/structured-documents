#!/bin/bash
#// AI-generated code

function  ShowHelp() {
    cat  <<_HERE_DOCUMENT
stop-hook.sh - Claude Code の Stop フックから呼ばれ、すべての検査が通るまで応答を終わらせないようにします
stop-hook.sh - Called from the Claude Code Stop hook; keeps the response from ending until all checks pass.

使い方:
Usage:
    .claude/settings.json の hooks.Stop から呼ばれます。手で実行する必要はありません
    Called from hooks.Stop in .claude/settings.json. No need to run it by hand.

    stdin に Claude Code から JSON を受け取ります。stop_hook_active が true のとき(このフックで
    すでに1回続けさせたあと)は、無限に続かないように、検査せずに終了コード 0 で終わります
    Receives JSON from Claude Code on stdin. When stop_hook_active is true (this hook already made
    Claude continue once), it exits with 0 without checking, so the loop cannot run forever.
    検査が失敗すると、失敗した検査の名前を stderr に出し、終了コード 2 で終わります。
    Claude Code はこれを受けて、応答を終えずに作業を続けます
    When checks fail, it writes the failed check names to stderr and exits with 2,
    and Claude Code continues working instead of ending the response.
_HERE_DOCUMENT
}

#region: CommandLineOptions

Options_Help=""
PositionalArgs=()
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)  Options_Help="yes"; shift;;
        -*) echo "Unknown option $1"; exit 1;;
        *) PositionalArgs+=("$1"); shift;;
    esac
done
set -- "${PositionalArgs[@]}"  #// set $1, $2, ...
unset PositionalArgs

#endregion:

#region: Main

function  Main() {
    #// 検査を実行し、失敗していれば Claude Code に作業を続けさせる
    #// Runs the checks, and makes Claude Code continue working if any check fails.
    local  hookInput=""
    local  checksFolderPath=""
    local  checkOutput=""
    local  checkStatus=0
    if [ "${Options_Help}" == "yes" ]; then
        ShowHelp
        exit  0
    fi
    hookInput="$( cat )"  #// function stdin
    if IsStopHookActive  "${hookInput}"; then
        exit  0
    fi
    checksFolderPath="$( cd  "$( dirname  "${BASH_SOURCE[0]}" )"  &&  pwd )"  ||  Error

    checkOutput="$( bash  "${checksFolderPath}/run-checks.sh"  2>&1 )"  ||  checkStatus=$?

    if (( checkStatus != 0 )); then
        {
            echo  "検査が通っていません。CLAUDE.md の「ループ」に従って直してから、もう一度 checks/run-checks.sh を実行してください。"
            echo  "Checks are failing. Fix them following the loop in CLAUDE.md, then run checks/run-checks.sh again."
            echo  "${checkOutput}"  |  grep  -E  '^not ok'
        }  >&2

        #// 終了コード 2 は、Claude Code の Stop フックで「終わらせずに続けさせる」という意味(エラーではない)
        #// Exit code 2 means "do not stop; continue" for a Claude Code Stop hook (not an error).
        exit  2
    fi
}

#endregion:

#region: HookInput

function  IsStopHookActive() {
    #// Claude Code から受け取った JSON で、stop_hook_active が true かどうか
    #// Whether stop_hook_active is true in the JSON received from Claude Code.
    local  hookInput="$1"

    if [[ "${hookInput}" =~ \"stop_hook_active\"[[:space:]]*:[[:space:]]*true ]]; then
        return  0
    fi
    return  1
}

#endregion:

#region: Error

function  Error() {
    local  errorMessage="${1-""}"  #// "${1-""}" means that "$1" default is "".
    if [ "${errorMessage}" == "" ]; then
        errorMessage="ERROR"
    fi

    echo  "${errorMessage}"  >&2
    exit  1
}

#endregion:

Main  "$@"
