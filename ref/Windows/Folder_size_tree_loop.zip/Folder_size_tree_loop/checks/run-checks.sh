#!/bin/bash
#// AI-generated code

function  ShowHelp() {
    cat  <<_HERE_DOCUMENT
run-checks.sh - フォルダー サイズ ビューアーのすべての検査を実行します
run-checks.sh - Runs all checks for the folder size viewer.

使い方:
Usage:
    checks/run-checks.sh

    すべての検査が通れば終了コード 0、1つでも失敗すれば 1 を返します
    Exits with 0 if all checks pass, or 1 if any check fails.
    検査の出力は checks/output フォルダーに置かれ、実行のたびに作り直されます
    Check outputs go to the checks/output folder, which is recreated on every run.

前提: node (22 以降)、bash、GNU find、awk。Playwright、pwsh、shellcheck がなければ、それを使う検査はスキップされます
Requires: node (22 or later), bash, GNU find, awk. Checks that need Playwright, pwsh or shellcheck are skipped without them.
_HERE_DOCUMENT
}

#region: CommandLineOptions

Options_Help=""
PositionalArgs=()
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)  Options_Help="yes"; shift;;
        -*) echo "Unknown option $1"; exit 1;;
        *) PositionalArgs+=("$1"); shift;;
    esac
done
set -- "${PositionalArgs[@]}"  #// set $1, $2, ...
unset PositionalArgs

#endregion:

#region: Main

function  Main() {
    #// 検査の出力フォルダーを作り直してから、checks フォルダーのすべての検査を実行する
    #// Recreates the check output folder, then runs every check in the checks folder.
    local  checksFolderPath=""
    local  testStatus=0
    if [ "${Options_Help}" == "yes" ]; then
        ShowHelp
        exit  0
    fi
    checksFolderPath="$( cd  "$( dirname  "${BASH_SOURCE[0]}" )"  &&  pwd )"  ||  Error
    rm -rf  "${checksFolderPath}/output"  ||  Error  "ERROR: checks/output を削除できません (cannot remove checks/output)"

    node  --test  "${checksFolderPath}/"*.test.mjs  ||  testStatus=$?

    if (( testStatus == 0 )); then
        echo  "すべての検査が通りました (all checks passed)"
    else
        Error  "ERROR: 失敗した検査があります (some checks failed)"
    fi
}

#endregion:

#region: Error

function  Error() {
    local  errorMessage="${1-""}"  #// "${1-""}" means that "$1" default is "".
    if [ "${errorMessage}" == "" ]; then
        errorMessage="ERROR"
    fi

    echo  "${errorMessage}"  >&2
    exit  1
}

#endregion:

Main  "$@"
