// AI-generated code
// ビューアー(Folder_size_tree.html)の検査。Playwright の Chromium でページを開いて確かめる
// Checks for the viewer (Folder_size_tree.html), opening the page in Playwright's Chromium.
//
// 実行: プロジェクトのフォルダーで  node --test checks/
// Run: in the project folder,  node --test checks/
// 事前に必要な準備: npm install playwright  と  npx playwright install chromium (Playwright が使えないホストでは、この検査をスキップする)
// Preparation: npm install playwright  and  npx playwright install chromium (these checks are skipped where Playwright is unavailable).

import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";

const checksFolderPath = path.dirname(fileURLToPath(import.meta.url));
const projectFolderPath = path.dirname(checksFolderPath);
const viewerUrl = pathToFileURL(path.join(projectFolderPath, "Folder_size_tree.html")).href;
const expectedOutputPath = path.join(checksFolderPath, "test_data", "Expected_output.yaml");

const playwright = LoadPlaywright();
let  browser = null;

before(async function () {
    if (playwright !== null) {
        browser = await playwright.chromium.launch();
    }
});

after(async function () {
    if (browser !== null) {
        await browser.close();
    }
});

const skipReason = (playwright === null) ? "Playwright がない" : false;

test("[汎用] ページを開いて読み込んでも、スクリプトのエラーが出ない", { skip: skipReason }, async function () {
    const { page, pageErrors } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    assert.deepEqual(pageErrors, []);
    await page.close();
});

test("[汎用] 幅 390px でも、ページが横にはみ出さない", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(390);
    await LoadExpectedOutput(page);

    assert.ok(await page.evaluate(function () { return document.documentElement.scrollWidth; }) <= 390);
    await page.close();
});

test("[会話] 読み込んだ直後は、サイズの大きい順に並ぶ", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    assert.deepEqual(await ChildNames(page), ["sp ace", "a", "a-b", "B", ".hidden", "empty"]);
    await page.close();
});

test("[会話] 名前順は、大文字・小文字を区別しないものと、区別するものの2種類がある", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    await page.selectOption("#sortSelect", "name-asc");
    assert.deepEqual(await ChildNames(page), [".hidden", "a", "a-b", "B", "empty", "sp ace"]);

    await page.selectOption("#sortSelect", "name-case-asc");
    assert.deepEqual(await ChildNames(page), [".hidden", "B", "a", "a-b", "empty", "sp ace"]);
    await page.close();
});

test("[会話] 棒グラフの割合は、同じ親フォルダーの中での割合", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);
    await page.click("#expandAllButton");

    assert.equal(await PercentageOf(page, "a"), "26.3%");
    assert.equal(await PercentageOf(page, "b"), "60.0%");
    await page.close();
});

test("[会話] 展開できないフォルダーにマウスを合わせても、行が明るくなる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);
    const rowLocator = page.locator(".row:not(.has-children)", { has: page.locator(".name", { hasText: /^empty$/ }) }).first();
    const backgroundBefore = await rowLocator.evaluate(function (element) { return getComputedStyle(element).backgroundColor; });
    await rowLocator.hover();

    assert.notEqual(await rowLocator.evaluate(function (element) { return getComputedStyle(element).backgroundColor; }), backgroundBefore);
    await page.close();
});

test("[会話] スクリプトのポップアップが開いて、閉じるボタンと Esc キーで閉じる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);

    assert.equal(await page.isVisible("#scriptOverlay"), false);
    await page.click("#showScriptButton");
    assert.equal(await page.isVisible("#scriptOverlay"), true);
    await page.click("#closeScriptButton");
    assert.equal(await page.isVisible("#scriptOverlay"), false);
    await page.click("#showScriptButton");
    await page.keyboard.press("Escape");
    assert.equal(await page.isVisible("#scriptOverlay"), false);
    await page.close();
});

test("[会話] ポップアップで PowerShell とシェルスクリプトを切り替えられる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await page.click("#showScriptButton");

    assert.equal(await page.textContent("#scriptModalTitle"), "Folder_size_tree.ps1");
    await page.click(".scriptKindButton[data-script-kind='shellScript']");
    assert.equal(await page.textContent("#scriptModalTitle"), "folder-size-tree.sh");
    assert.equal(await page.isVisible("#shellScriptSourceCode"), true);
    assert.equal(await page.isVisible("#powerShellSourceCode"), false);
    await page.close();
});

test("[自動生成] ビューアーに埋め込んだスクリプトが、スクリプトのファイルと一致する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);

    assert.equal(await page.textContent("#scriptSourceRaw"), ReadText(path.join(projectFolderPath, "Folder_size_tree.ps1")));
    assert.equal(await page.textContent("#shellScriptSourceRaw"), ReadText(path.join(projectFolderPath, "folder-size-tree.sh")));
    await page.close();
});

test("[自動生成] 形式に合わない行と空の行は読み飛ばし、エラーにしない", { skip: skipReason }, async function () {
    const { page, pageErrors } = await OpenViewer(1280);
    await LoadText(page, "root:  #// 100\n\nthis line has no size\n    a:  #// 60\n  :  #// broken\n    b:  #// 40\n");

    assert.deepEqual(await ChildNames(page), ["a", "b"]);
    assert.deepEqual(pageErrors, []);
    await page.close();
});

test("[自動生成] ファイルを点線の枠にドラッグ&ドロップすると読み込み、テキストエリアにも表示する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    const fileText = ReadText(expectedOutputPath);
    const dataTransferHandle = await page.evaluateHandle(function (text) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(new File([text], "Folder_size_tree_out.yaml", { type: "text/plain" }));
        return dataTransfer;
    }, fileText);
    await page.dispatchEvent("#dropZone", "drop", { dataTransfer: dataTransferHandle });
    await page.waitForFunction(function () { return document.querySelector("#treeContainer .node") !== null; });

    assert.equal(await page.inputValue("#textInput"), fileText);
    assert.deepEqual(await ChildNames(page), ["sp ace", "a", "a-b", "B", ".hidden", "empty"]);
    await page.close();
});

test("[自動生成] 点線の枠をクリックしてファイルを選ぶと読み込み、テキストエリアにも表示する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    const fileChooserPromise = page.waitForEvent("filechooser");
    await page.click("#dropZone");
    const fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(expectedOutputPath);
    await page.waitForFunction(function () { return document.querySelector("#treeContainer .node") !== null; });

    assert.equal(await page.inputValue("#textInput"), ReadText(expectedOutputPath));
    assert.deepEqual(await ChildNames(page), ["sp ace", "a", "a-b", "B", ".hidden", "empty"]);
    await page.close();
});

test("[自動生成] 何も読み込んでいないときは、案内の文を表示する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadText(page, "");

    assert.equal(await page.textContent("#emptyState"), "YAML を貼り付けるかファイルを選ぶと、ここにツリーが表示されます。");
    await page.close();
});

test("[会話] 各行に、フォルダー名、3桁区切りのサイズ、割合、棒グラフを表示する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);
    const rootRow = await page.evaluate(function () {
        const row = document.querySelector("#treeContainer .node > .row");
        return {
            name: row.querySelector(".name").textContent,
            size: row.querySelector(".size").textContent,
            percentage: row.querySelector(".percentage").textContent,
            barWidth: row.querySelector(".bar-outer > .bar-inner").style.width,
        };
    });

    assert.deepEqual(rootRow, { name: "Scan_root", size: "18,982", percentage: "100.0%", barWidth: "100%" });
    await page.close();
});

test("[自動生成] 割合は 100% を超えず、親のサイズが 0 のときは 0% にする", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadText(page, "root:  #// 100\n    big:  #// 150\n    zero:  #// 0\n        child:  #// 5\n");
    await page.click("#expandAllButton");

    assert.equal(await PercentageOf(page, "big"), "100.0%");
    assert.equal(await PercentageOf(page, "child"), "0.0%");
    await page.close();
});

test("[自動生成] 読み込んだ直後は、ルートだけを開いた状態にする", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    assert.deepEqual(await VisibleNames(page), ["Scan_root", "sp ace", "a", "a-b", "B", ".hidden", "empty"]);
    await page.close();
});

test("[会話] 子フォルダーのある行をクリックすると、開閉する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);
    const rowOfA = page.locator(".row.has-children", { has: page.locator(".name", { hasText: /^a$/ }) });

    await rowOfA.click();
    assert.ok((await VisibleNames(page)).includes("b"));
    await rowOfA.click();
    assert.ok(!(await VisibleNames(page)).includes("b"));
    await page.close();
});

test("[会話] 「すべて展開」ですべての行を開き、「すべて折りたたむ」ですべての行を閉じる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    await page.click("#expandAllButton");
    assert.equal((await VisibleNames(page)).length, 8);
    await page.click("#collapseAllButton");
    assert.deepEqual(await VisibleNames(page), ["Scan_root"]);
    await page.close();
});

test("[会話] 並べ替えは6種類で、それぞれの順に並ぶ", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);
    const optionValues = await page.$$eval("#sortSelect option", function (options) {
        return options.map(function (option) { return option.value; });
    });

    assert.deepEqual(optionValues, ["size-desc", "size-asc", "name-asc", "name-desc", "name-case-asc", "name-case-desc"]);
    await page.selectOption("#sortSelect", "size-asc");
    assert.deepEqual(await ChildNames(page), ["empty", ".hidden", "B", "a-b", "a", "sp ace"]);
    await page.selectOption("#sortSelect", "name-desc");
    assert.deepEqual(await ChildNames(page), ["sp ace", "empty", "B", "a-b", "a", ".hidden"]);
    await page.selectOption("#sortSelect", "name-case-desc");
    assert.deepEqual(await ChildNames(page), ["sp ace", "empty", "a-b", "a", "B", ".hidden"]);
    await page.close();
});

test("[自動生成] 並べ替えは、すべての階層の兄弟フォルダーに適用する", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadText(page, "root:  #// 100\n    p:  #// 100\n        small:  #// 10\n        large:  #// 90\n");
    await page.click("#expandAllButton");

    assert.deepEqual(await VisibleNames(page), ["root", "p", "large", "small"]);
    await page.selectOption("#sortSelect", "size-asc");
    await page.click("#expandAllButton");
    assert.deepEqual(await VisibleNames(page), ["root", "p", "small", "large"]);
    await page.close();
});

test("[会話] 名前の列の幅は、見出しの境目をドラッグして 100〜480px の範囲で変えられる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    assert.equal(await DragResizer(page, "#nameResizer", "--name-width", 50), "270px");
    assert.equal(await DragResizer(page, "#nameResizer", "--name-width", 1000), "480px");
    assert.equal(await DragResizer(page, "#nameResizer", "--name-width", -1000), "100px");
    await page.close();
});

test("[会話] 棒グラフの列の幅は、見出しの境目をドラッグして 60〜320px の範囲で変えられる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await LoadExpectedOutput(page);

    assert.equal(await DragResizer(page, "#barResizer", "--bar-width", 30), "170px");
    assert.equal(await DragResizer(page, "#barResizer", "--bar-width", 1000), "320px");
    assert.equal(await DragResizer(page, "#barResizer", "--bar-width", -1000), "60px");
    await page.close();
});

test("[自動生成] スクリプトのポップアップは、外側をクリックしても閉じる", { skip: skipReason }, async function () {
    const { page } = await OpenViewer(1280);
    await page.click("#showScriptButton");
    await page.mouse.click(5, 5);

    assert.equal(await page.isVisible("#scriptOverlay"), false);
    await page.close();
});

test("[汎用] ネットワークを使わず、1つの HTML ファイルだけで動く", { skip: skipReason }, async function () {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const requestedUrls = [];
    page.on("request", function (request) { requestedUrls.push(request.url()); });
    await page.goto(viewerUrl);
    await LoadExpectedOutput(page);
    await page.click("#expandAllButton");
    await page.click("#showScriptButton");

    assert.deepEqual(requestedUrls.filter(function (url) { return !url.startsWith("file:"); }), []);
    await page.close();
});

test("[会話] 文字コードを、ファイルの先頭 1024 バイト以内の meta 要素で UTF-8 と宣言している", async function () {
    // 宣言がないと、ブラウザーは文字コードを推測する。Chromium は UTF-8 と推測できても、Safari では文字化けした
    // Without the declaration, the browser guesses the encoding. Chromium guessed UTF-8, but Safari showed garbled text.
    const headText = fs.readFileSync(path.join(projectFolderPath, "Folder_size_tree.html")).subarray(0, 1024).toString("latin1");

    assert.match(headText, /<meta\s+charset="?utf-8"?\s*\/?>/i);
});

test("[会話] スクリプトのソースの右上にコピー ボタンがあり、押すとソース全体がクリップボードにコピーされる", { skip: skipReason }, async function () {
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    await context.grantPermissions(["clipboard-read", "clipboard-write"]);
    const page = await context.newPage();
    await page.goto(viewerUrl);
    await page.click("#showScriptButton");
    const scriptCases = [
        { kind: "powerShell", fileName: "Folder_size_tree.ps1" },
        { kind: "shellScript", fileName: "folder-size-tree.sh" },
    ];

    for (const scriptCase of scriptCases) {
        await page.click(`.scriptKindButton[data-script-kind="${scriptCase.kind}"]`);
        const panelSelector = `.scriptPanel[data-script-kind="${scriptCase.kind}"]`;
        const buttonBox = await page.locator(`${panelSelector} .copyScriptButton`).boundingBox();
        const sourceBox = await page.locator(`${panelSelector} .scriptSourceCode`).boundingBox();
        assert.ok(sourceBox.x + sourceBox.width - (buttonBox.x + buttonBox.width) < 30, "右端に近い");
        assert.ok(buttonBox.y - sourceBox.y < 30, "上端に近い");

        await page.click(`${panelSelector} .copyScriptButton`);
        assert.equal(await page.evaluate(function () { return navigator.clipboard.readText(); }), ReadText(path.join(projectFolderPath, scriptCase.fileName)));
        assert.equal(await page.textContent(`${panelSelector} .copyScriptButton`), "コピーしました");
    }
    await context.close();
});

async function  OpenViewer(viewportWidth) {
    // ビューアーを指定の幅で開く。ページで起きたスクリプトのエラーを集める配列も返す
    // Opens the viewer at the given width, and returns an array that collects script errors on the page.
    const page = await browser.newPage({ viewport: { width: viewportWidth, height: 900 } });
    const pageErrors = [];
    page.on("pageerror", function (error) { pageErrors.push(error.message); });
    await page.goto(viewerUrl);

    return { page, pageErrors };
}

async function  LoadExpectedOutput(page) {
    // 期待する出力(checks/test_data/Expected_output.yaml)を、テキストエリアに貼り付けて読み込む
    // Pastes the expected output (checks/test_data/Expected_output.yaml) into the textarea and loads it.

    await page.fill("#textInput", ReadText(expectedOutputPath));
    await page.click("#parseButton");
}

async function  ChildNames(page) {
    // ルートのフォルダーの直下にあるフォルダーの名前を、表示の順に返す
    // Returns the names of the folders directly under the root folder, in display order.

    return page.evaluate(function () {
        const rootNode = document.querySelector("#treeContainer .node");
        const childNodes = rootNode.querySelectorAll(":scope > .children > .node");

        return [...childNodes].map(function (node) { return node.querySelector(":scope > .row .name").textContent; });
    });
}

async function  PercentageOf(page, folderName) {
    // 指定した名前のフォルダーの行に表示されている割合
    // The percentage shown on the row of the folder with the given name.

    return page.evaluate(function (name) {
        for (const row of document.querySelectorAll("#treeContainer .row")) {
            if (row.querySelector(".name").textContent === name) {
                return row.querySelector(".percentage").textContent;
            }
        }
        return null;
    }, folderName);
}

async function  LoadText(page, text) {
    // 指定の文字列をテキストエリアに貼り付けて読み込む
    // Pastes the given text into the textarea and loads it.

    await page.fill("#textInput", text);
    await page.click("#parseButton");
}

async function  VisibleNames(page) {
    // 画面に見えている行のフォルダー名を、表示の順に返す
    // Returns the folder names of the rows currently visible, in display order.

    return page.$$eval("#treeContainer .row", function (rows) {
        return rows.filter(function (row) { return row.offsetParent !== null; })
            .map(function (row) { return row.querySelector(".name").textContent; });
    });
}

async function  DragResizer(page, resizerSelector, cssVariableName, movedPixel) {
    // 列の境目のつまみを横にドラッグし、そのあとの列幅(CSS 変数の値)を返す
    // Drags a column resizer horizontally and returns the resulting column width (CSS variable value).
    const box = await page.locator(resizerSelector).boundingBox();
    const startX = box.x + box.width / 2;
    const startY = box.y + box.height / 2;
    await page.mouse.move(startX, startY);
    await page.mouse.down();
    await page.mouse.move(startX + movedPixel, startY, { steps: 5 });
    await page.mouse.up();

    return page.evaluate(function (name) {
        return document.documentElement.style.getPropertyValue(name).trim();
    }, cssVariableName);
}

function  ReadText(filePath) {
    // ファイルを UTF-8 の文字列として読む。先頭の BOM は取り除く
    // Reads a file as a UTF-8 string, removing a leading BOM.

    return fs.readFileSync(filePath, "utf8").replace(/^﻿/, "");
}

function  LoadPlaywright() {
    // Playwright を読み込む。読み込めなければ null を返す
    // Loads Playwright, or returns null if it cannot be loaded.
    try {
        const require = createRequire(import.meta.url);

        return require("playwright");
    } catch {
        return null;
    }
}
