﻿param (
    [string]$Root = "C:\Users\me\Projects",

    # 出力先。既定では、このスクリプトファイル自身があるフォルダー($PSScriptRoot)の
    # Folder_size_tree_out.yaml に書き出す(-Root で指定した走査対象のフォルダーではない)
    [string]$OutFile = (Join-Path $PSScriptRoot "Folder_size_tree_out.yaml")
)

# 走査対象のフォルダーがなければ、出力ファイルを作らずにエラーで止める
# If the folder to scan does not exist, stop with an error without creating the output file.
if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
    Write-Error "Folder not found: $Root" -ErrorAction Continue
    exit 1
}

$rootPath = (Resolve-Path -LiteralPath $Root).Path.TrimEnd('\')

# フォルダーごとの合計サイズ
$sizes = @{}

Write-Host "Scanning directories..."

# 先に全フォルダーを登録
$directories = @(
    Get-Item -LiteralPath $rootPath -Force
    Get-ChildItem -LiteralPath $rootPath -Directory -Recurse -Force -ErrorAction SilentlyContinue
)

foreach ($dir in $directories) {
    $sizes[$dir.FullName.TrimEnd('\')] = [Int64]0
}

Write-Host "Directories: $($directories.Count)"
Write-Host "Scanning files..."

$fileCount = [Int64]0
$totalBytes = [Int64]0

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$lastProgressTime = 0.0

# 全ファイルを1回だけ走査
Get-ChildItem -LiteralPath $rootPath -File -Recurse -Force -ErrorAction SilentlyContinue |
    ForEach-Object {

        $fileCount++
        $size = $_.Length
        $totalBytes += $size

        $current = $_.Directory.FullName.TrimEnd('\')

        # ファイルサイズを親フォルダーへ積み上げる
        while ($current.StartsWith(
            $rootPath,
            [System.StringComparison]::OrdinalIgnoreCase
        )) {
            if ($sizes.ContainsKey($current)) {
                $sizes[$current] += $size
            }

            if ($current -eq $rootPath) {
                break
            }

            $parent = [System.IO.Directory]::GetParent($current)

            if ($null -eq $parent) {
                break
            }

            $current = $parent.FullName.TrimEnd('\')
        }

        # 前回の進捗表示から2秒以上経過した場合だけ更新
        if (($stopwatch.Elapsed.TotalSeconds - $lastProgressTime) -ge 2) {

            $elapsed = $stopwatch.Elapsed

            Write-Progress `
                -Activity "Scanning files" `
                -Status (
                    "{0:N0} files / {1:N0} bytes / {2:hh\:mm\:ss}" -f `
                        $fileCount,
                        $totalBytes,
                        $elapsed
                ) `
                -CurrentOperation $_.FullName

            $lastProgressTime = $stopwatch.Elapsed.TotalSeconds
        }
    }

$stopwatch.Stop()

Write-Progress -Activity "Scanning files" -Completed

Write-Host (
    "Scan completed: {0:N0} files, {1:N0} bytes, {2:hh\:mm\:ss}" -f `
        $fileCount,
        $totalBytes,
        $stopwatch.Elapsed
)

function Write-FolderTree {
    param (
        [Parameter(Mandatory)]
        [string]$Path,

        [int]$Depth = 0
    )

    $item = Get-Item -LiteralPath $Path -Force
    $indent = "    " * $Depth
    $size = $sizes[$item.FullName.TrimEnd('\')]

    Write-Output "$indent$($item.Name)`:  #// $($size.ToString('N0'))"

    Get-ChildItem -LiteralPath $Path -Directory -Force -ErrorAction SilentlyContinue |
        Sort-Object Name |
        ForEach-Object {
            Write-FolderTree -Path $_.FullName -Depth ($Depth + 1)
        }
}

Write-FolderTree -Path $rootPath | Out-File -LiteralPath $OutFile -Encoding utf8

Write-Host "Output written to: $OutFile"
